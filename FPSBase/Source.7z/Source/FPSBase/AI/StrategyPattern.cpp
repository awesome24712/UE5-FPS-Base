#include "StrategyPattern.h"
