#pragma once
class StrategyPattern
{
};

