#pragma once

#include "CoreMinimal.h"

#ifndef FPSBASE_API
#define FPSBASE_API
#endif

typedef unsigned char      byte;
typedef unsigned short     ushort;
typedef unsigned int       uint;
typedef unsigned long long ulong;
typedef float              ftime; // time
typedef float              vec;   // float representing world space (used by vectors)
typedef unsigned short     eindex; // entity index
typedef float              lerp;   // linear interpolation

#define STRINGIZE(tokens) #tokens // stringifies a token

#define until(condition) while (!(condition)) // simplifies thinking in many contexts
//#define INTERFACE        class // abstract class never directly constructed


FORCEINLINE bool CharIsNumber(TCHAR c) { return c <= '9' && c >= '0'; }
